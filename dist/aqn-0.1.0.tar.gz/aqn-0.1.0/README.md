# AQN PIP Package
A little meme package I made after talking about how shit python can be with my friend @tsunyoku