"""
aqn

the most meme library on all of pip after xevel
"""

__version__ = "0.1.0"
__author__ = "lyryhn"